# Create-your-map
# leaflet map offline



Create your map by leaflet js 
 - how to use leaflet js to create map 
- offline map and can be working online and mobile applicatioin
- how to use Mobile Atlas Creator (atlases)
- Create map marker and bindPopup 
- Multi Layer on map by open street view 
- how add multi icon Url
- Your location found 
- HTML5 offline map with local tiles via Leaflet

## leaflet Map


[![Watch the video](https://img.youtube.com/vi/oP4bCLtXIeY/0.jpg)](https://youtu.be/oP4bCLtXIeY)

## Create map leaflet

1- Download software Mobile Atlas Creator
2- Create a new atlas with OSMdroid ZIP format and download layers 
3- HTML (javasript) Code format: {atlas_name}/{z}/{x}/{y}.png 
# Notes : 
1 - Max tiles 500,000 for downloads  (show video to solve it)   
2 - {z}  meaning = level of zoom

## Can be start web Augmented reality

Https://Webxr.edafait.com

## YouTube Channel Wonder developer To Subscriber 
https://youtube.com/channel/UCNJVG9_IebHe-NF-K_Y8Grw?sub_confirmation=1

